from django.apps import AppConfig


class SeffafistatistikConfig(AppConfig):
    name = 'seffafistatistik'
